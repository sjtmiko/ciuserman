<?php 
if ($nav) {
  $this->load->view($nav);
}
 ?>