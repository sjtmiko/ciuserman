<!-- Begin Page Content -->  
<div class="container-fluid">
	<!-- Page Heading -->
	<h1 class="h3 mb-4 text-gray-800">Dashboard Manajemen User Hotspot</h1>
</div>
<!-- /.container-fluid -->
