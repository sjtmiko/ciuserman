<!-- Begin Page Content -->  
<div class="container-fluid">
	<!-- Page Heading -->
	<h1 class="h3 mb-4 text-gray-800">Manajemen User Hotspot</h1>
</div>
<!-- /.container-fluid -->

<div class="container-fluid">
	<!-- Page Heading -->
	<a class="btn btn-primary mb-2" href="<?= base_url('index.php/admin/user_add') ?>">Tambah User</a>
	<table class="table bg-white">
		<thead>
			<tr>
				<th scope="col">No</th>
				<th scope="col">Username</th>
				<th scope="col">Password</th>
			</tr>
		</thead>
		<tbody>
			<?php 
			$i=1;
			foreach ($user as $row): ?>
			<tr>
				<th scope="row"><?php echo $i++; ?></th>
				<td><?php echo $row->username; ?></td>
				<td><?php echo $row->value; ?></td>
				<td>
					<a href="<?= base_url('index.php/admin/user_edit/'.$row->id) ?>">Edit</a> |
					<a href="<?= base_url('index.php/admin/user_delete/'.$row->id) ?>">Hapus</a> 
				</td>
			</tr>
			<?php endforeach ?>
		</tbody>
	</table>
</div>