<!-- Begin Page Content -->  
<div class="container-fluid">
	<h1 class="h3 mb-4 text-gray-800">Tambah User Hotspot</h1>
	<!-- Page Heading -->
	<form method="post" action="<?= base_url('index.php/admin/user_add_act') ?>">
		<div class="form-group">
			<label>Username</label>
			<input type="text" class="form-control" name="username">
		</div>
		<div class="form-group">
			<label>Attribure</label>
			<input type="text" class="form-control" name="attribute" value="Password">
		</div>
		<div class="form-group">
			<label>Password</label>
			<input type="text" class="form-control" name="value">
		</div>
		<button type="submit" class="btn btn-primary">Submit</button>
		<a class="btn btn-warning" href="<?= base_url('index.php/admin/admin') ?>">Batal</a>
	</form>
</div>
<!-- /.container-fluid -->
