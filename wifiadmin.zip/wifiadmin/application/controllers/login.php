<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
 
class Login extends CI_Controller{
 
	public function __construct(){
		parent::__construct();		
		$this->load->model('m_login');
	}
 
	public function index(){
		$this->load->view('view_new');
	}

	public function auth(){
		$name=$this->input->post('name');
		$password=$this->input->post('password');

		$where = array(
			'name' => $name,
			'password' => md5($password)
			);

		$cek_user=$this->m_login->auth($where);

        if($cek_user->num_rows() > 0){ //jika login sebagai dosen
        	$data = $cek_user->row_array();

            if($data['level']=='1'){ //Akses admin
            	$data_session = array(
	        		'nama' => $name,
	        		'status' => "admin");
            	$this->session->set_userdata($data_session);
             	echo "Berhasil Anda adalah";
             	//redirect('index.php/admin');
            }elseif ($data['level']=='2') { //Akses dsoen
            	$data_session = array(
	        		'nama' => $name,
	        		'status' => "owner");
            	$this->session->set_userdata($data_session);
             	redirect('dosen');
            }else{
            	$this->session->set_flashdata('msg_login', 'Maaf name dan password salah!');
            	redirect('login');
            }
        }else{ //jika login gagal
        	$this->session->set_flashdata('msg_login', 'Maaf name dan password salah!');
			redirect('login');
	    }
	}
	 
	public function logout(){
		$this->session->sess_destroy();
		redirect('login');
	}
}