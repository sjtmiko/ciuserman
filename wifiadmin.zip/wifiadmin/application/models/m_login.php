<?php 
 
class M_login extends CI_Model{	
	//cek nip dan password dosen
    function auth($where){
        return $this->db->get_where('login_db',$where);
    }
}